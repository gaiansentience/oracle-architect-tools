clear all records from the environment table
delete from app#environment;
commit;
