prompt Deploy Extra Example Objects For Advanced PL/SQL Instrumentation Presentation
prompt Anthony Harper, Information Architects, Senior Technical Architect, 2007
prompt Anthony.Harper@corporateinformationarchitects.com
prompt 917.856.9015
Prompt Deploy Example Logging Packages
@@log#no_control.spc; 
@@log#compiled_control.spc; 
@@log#control_without_interface.spc; 
@@log#interface.spc; 
@@log#test_interface.spc; 
@@log#your_interface.spc;
@@log#no_control.bdy; 
@@log#compiled_control.bdy; 
@@log#control_without_interface.bdy; 
@@log#interface.bdy; 
@@log#test_interface.bdy; 
@@log#your_interface.bdy;
Prompt Finished Deploying Examples
Prompt use drop_extra_examples.sql to drop
prompt Thank You, Anthony Harper, Senior Technical Architect
