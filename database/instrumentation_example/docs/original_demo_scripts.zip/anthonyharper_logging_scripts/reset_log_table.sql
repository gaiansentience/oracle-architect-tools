begin
   app#log_util.purge_logs;
end;
/
