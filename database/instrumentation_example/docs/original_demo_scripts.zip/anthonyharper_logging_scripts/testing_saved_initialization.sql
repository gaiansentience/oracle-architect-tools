PL/SQL Developer Test script 3.0
7
begin
   -- Call the procedure
   my_package.my_other_procedure('testing_1', 'test_user');
   -- Call the procedure again
   my_package.my_other_procedure('testing_2', 'test_user');
end;
--/
0
0
