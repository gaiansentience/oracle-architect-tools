prompt Drop Extra Example Objects For Advanced PL/SQL Instrumentation Presentation
prompt Anthony Harper, Information Architects, Senior Technical Architect, 2007
prompt Anthony.Harper@corporateinformationarchitects.com
prompt 917.856.9015
Prompt Drop Example Logging Packages
DROP PACKAGE log#no_control; 
DROP PACKAGE log#compiled_control; 
DROP PACKAGE log#control_without_interface; 
DROP PACKAGE log#interface; 
DROP PACKAGE log#test_interface; 
DROP PACKAGE log#your_interface;
Prompt Finished Deploying Examples
Prompt use deploy_extra_examples.sql to recreate
prompt Thank You, Anthony Harper, Senior Technical Architect
